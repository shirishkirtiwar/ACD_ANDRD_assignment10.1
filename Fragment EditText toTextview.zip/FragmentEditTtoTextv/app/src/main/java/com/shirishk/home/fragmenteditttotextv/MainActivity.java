package com.shirishk.home.fragmenteditttotextv;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button b;
    EditText et;
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b = (Button) findViewById(R.id.button);
        et = (EditText) findViewById(R.id.editText2);
        tv = (TextView) findViewById(R.id.textview1);

        b.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                String str = et.getText().toString();
                tv.setText(str);
            }
        });


    }
}
